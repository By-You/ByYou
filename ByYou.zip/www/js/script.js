$(function() {
//slider
  $('#coin-slider').coinslider({width:960,height:360,opacity:1});
//navigace
  $('.menu_nav ul li a').css({"border-top-left-radius":"6px", "border-top-right-radius":"6px", "-moz-border-radius-topleft":"6px", "-moz-border-radius-topright":"6px", "-webkit-border-top-left-radius":"6px", "-webkit-border-top-right-radius":"6px"});
});	

Cufon.replace('h1, h2, h3, h4, h5, h6, .content .mainbar a.com, .content .mainbar a.rm', { hover: true });
