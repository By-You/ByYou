<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\AdminModule/templates/Products/edit.latte

class Template309415bccf9a72922feaf94a936c992d extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('127f2e85a4', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb4dd1db05e4_content')) { function _lb4dd1db05e4_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="full_w">
<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>
            <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin($form = $_form = $_control["productForm"], array()) ?>

                					<div class="element">
                						<label for="name">Název</label>
                						<input id="name" class="text" value="<?php echo Latte\Runtime\Filters::escapeHtml($product->nazev, ENT_COMPAT) ?>
"<?php $_input = $_form["name"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'id' => NULL,
  'class' => NULL,
  'value' => NULL,
))->attributes() ?>>
                					</div>
                					<div class="element">
                						<label for="price">Cena v Kč</label>
                						<input id="price" class="text" value="<?php echo Latte\Runtime\Filters::escapeHtml($product->cena, ENT_COMPAT) ?>
"<?php $_input = $_form["price"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'id' => NULL,
  'class' => NULL,
  'value' => NULL,
))->attributes() ?>>
                					</div>
                					<div class="element">
                						<label for="velikost">Velikost</label>
                						<?php echo $_form["velikost"]->getControl() ?>

                						</div>
                					<div class="entry">
                						<button type="submit" class="edit"<?php $_input = $_form["send"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'type' => NULL,
  'class' => NULL,
))->attributes() ?>>Upravit</button>
                					</div>
            <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd($_form) ?>

			</div><?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb326b99908b_title')) { function _lb326b99908b_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>				<div class="h_title">Upravení produktu: <?php echo Latte\Runtime\Filters::escapeHtml($product->nazev, ENT_NOQUOTES) ?></div>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}