<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\presenters/templates/Homepage/default.latte

class Template3241946f1b181b26a39603585b3afaaa extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('4e9e10b83a', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb1404118d37_content')) { function _lb1404118d37_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div id="banner">
<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>
</div>

<div id="content">
	<h2>You have successfully created your Nette Framework project.</h2>

	<div class="boxes">
		<div>
			<h2><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAH4AAAB4CAMAAAADpLanAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAwBQTFRF29vb+/v7F5rK1NTUvL2/m7/EwsPFpKWmhYaGt7e5V7TElZaX4ODg9vb25eXl8fHxeXl4Wo6lfqPKQ5nJlJRiwLTIr7CxVX+Me77E4uTkX5/I5+jo0NHQgZKU5ubm4uLi5+fo5OPk5ufm1tbWo6m72NjY5+bmzs7P4+PjrKyt5OTk4uPj9PPz9PP08/Pz8/Tz9/f39PT019fX+Pj48/T06enp6Ojo6+vr6urq7Ozs7e3t/f397u7u7+/v8PDwwMHEQEBAQUFBQkJCQ0NDRERERUVFRkZGR0dHSEhISUlJSkpKS0tLTExMTU1NTk5OT09PUFBQUVFRUlJSU1NTVFRUVVVVVlZWV1dXWFhYWVlZWlpaW1tbXFxcXV1dXl5eX19fYGBgYWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpampqa2trbGxsbW1tbm5ub29vcHBwcXFxcnJyc3NzdHR0dXV1dnZ2d3d3eHh4eXl5enp6e3t7fHx8fX19fn5+f39/gICAgYGBgoKCg4ODhISEhYWFhoaGh4eHiIiIiYmJioqKi4uLjIyMjY2Njo6Oj4+PkJCQkZGRkpKSk5OTlJSUlZWVlpaWl5eXmJiYmZmZmpqam5ubnJycnZ2dnp6en5+foKCgoaGhoqKio6OjpKSkpaWlpqamp6enqKioqampqqqqq6urrKysra2trq6ur6+vsLCwsbGxsrKys7OztLS0tbW1tra2t7e3uLi4ubm5urq6u7u7vLy8vb29vr6+v7+/wMDAwcHBwsLCw8PDxMTExcXFxsbGx8fHyMjIycnJysrKy8vLzMzMzc3Nzs7Oz8/P0NDQ0dHR0tLS09PT1NTU1dXV1tbW19fX2NjY2dnZ2tra29vb3Nzc3d3d3t7e39/f4ODg4eHh4uLi4+Pj5OTk5eXl5ubm5+fn6Ojo6enp6urq6+vr7Ozs7e3t7u7u7+/v8PDw8fHx8vLy8/Pz9PT09fX19vb29/f3+Pj4+fn5+vr6+/v7/Pz8/f39/v7+////Cj5bZgAACgtJREFUeNrEm2lbozwUhsPpKrJJRDtVoWOrg6id0g5LsG3+/796PyRQlgSoy/Xmy9QZ57rPk7MmUES/d43HlA6HFxcvL5PLy+nUsqyL4X6/PxTrWFnou+njMaXDi4ubHH95j/b7kgE/iT/RJ5x+M9AWezkf/az2h6coW2QV/o/hBdq3zxlZZFkm46Of1D5FaZYlj1mV/zN4gfYnI8tIahA5H30zfVjWvthnJI0MUvB/DC/UTjKSRguD1PjfjxdpjzJC0ih2g4Txe+AdUNkHnH84Lay20sfj6+ubgn6zNbKMpNHCDYJEzi/hMVC6ApDC5HiunV6PXiaXl1PLsqbblGQkiWLX8HvhbYBCvQOgYpU6AKBSSjEAqA4AAIwA6BxgBjADUCn7ldzvw+vra+thalnW5J5pj93A14KkxBfjVwAztvmY2WCD6oBKHVDHGJhyrFJKHZWyv8cj5/Qr4zEdDi9urh8ur62pZVn3jyQjaXTnGp6mBWmSJG14B3JPO6BSagOlDqgroJTOwYFRefNtdQWj/PdsAABQ82pzzXZ+cu8nhPnd0zQUpCmXn+9+i3qOp5jhbVzDO4CBUgfPKF3BHEZ0PKZ5zF8/TKeWNR0w7bFreJqGkJ/W5Ut9z7dgRlfFzlLMLZqr1AZKbe5zOsSqA+p4PFfzSms9WJb1MvASHvO+piGE/IjJb8WzyGehtwIAzKKNhxeM2J8jSlfssw0sTADjEWX5fm1ZlmX9iSva0VNPfM81B0qpg2fDIt9p3mUsy7L+eHm+c/rWj6J897+MxwDAUhI4vVLrrHsvYbXO8Dl96UWF/G9Qz9ZQ3GHvfVLkO6cPfgIvrvN/vISQhOc7pw+8uOz8auKj75wu/niklO/o6Wm7HAwGXhxFsthD36n9lfe4snaOT78XL9L+SmoxvxwMBoOBFsudj75rungZ/CYkSaPYqNEHWhx/M55nXFn7YEEykkR3de2DZW98MWNUWvsc6qOHUHveYRl9W9C3PfEYCmx1suB9aNam/blKP2nfPvXC2wCU4nlR02AEgNU5zCh1sFruSWK/s6j73aQjLT5lngTPGy4G6sCIq1/BDFQbTgMgBpBovyOijGP0bnwxbmCVOjAr8A7H42IYOU1W5VOkX824bZXuG73Vl/E2OFi1cVk9FmlfPhNSTFYN7Uh7Djrxue9VNsfMVWrDCoZl9Xbe42p+37riasO1a57bB08phjnADAOM2GQBgAHmMGfznA0zod+Xiyxr8bvmGbHXC9/eYIdDofalUdc+qNEXqfZ1vCTfl3e5dl/od89w41Q79Zwv4Fu1v0p2/jFOCK87X8OL/U7qs02V7sYp2Zfw2WfxonwP2mPeNx6jhByO34Afj8d0TGnV78Upsk370fw6Xuj3jJRPEyK/p+RwNP8WPeezeGGdZ/O8Ic13N0qz/dFc69WW16Pf1+lzmNW1/8pIp9+zw9F80/Vmx+3o9w3t85mNR9Uel5Ekio0uv/8N9U1Lwxf1+/xeYQ4AM0odwOp8Nlzhq5fabCPu75yekMPRXOv6ZteNr/T7/GhLh8MVUAdmYxvPhjcXV1dXJe2tdd6NmHZd3+x2LQ1f1O/ZpQHQFQDA2MZjSuezm5vJ5PL29tayXpY+afW7x/PdfNP1zW6ndOFr/d5mFwrsmD+21TEdzu2bl8nV7W0+2yRpdNda57P90XwP9c1upyheJ77S7x3AlGLVhhHF8MfBs+EKTyYPV7flua610p78vlMUJTG68eV+zy8U5gAzwOMRxuoVvrp6qPW4xs5vK34v6Mo66IOv9Xf2ZKR2jsvPMi0xz/1+on8o2tn4aq2blOp8daZdlrUjzfN5vud+V5SPjw95x0VnnuOSjph34zSraK/hs7544WxD2v0ecO1hhf4ZvEj7L9JP+19d35zgBT7pjxfPdSQRn+Oqfl+HFe0lfMP56JzzO8/3V3m1KTJOKdHPxgvuLpZ3JEvS6M5oxvxTxe/veinm2UqkiY/6zjavPN+Dji7z1qR/7Lxz8CLtcX5r9Cr2e9Dw+4neUndQP7+/5jHf5few7nfu/N54wY1Z3t87/V6tNjV82gff1D4Z/Oo4w+ZT5VsopsvrDurUfsu1LwR+Z/Tfsnw/G9+MupfB7z61ro2uKNJRG3X5nd9dLDrr/FqQcZyuSOsO6tL+K+nO96yS7w3tiuK5ktBHHdofpfc2HXW+gjeDbnyr3zvy/W/Yol1RpHUHtWp3+WwTfDLfc3o3Xqg9JSSNFkZXzL930RVZ5qGWWrfg/d2Q7Hxnvit98eInI+w5bOD1qPPtdMVbiDMPSbRbnB6fke9yumIGLXiR9iDJEnnMe4X2t5ZqU6zdThJ7SKLdz5+MfLrOV+gteJH23509rr/flV2OTwV4od95pRWeZc71+47hhaGPxNq78p3V+X/9/L7bbTbNUf+Q4+uTlVc9SW3r9IDfGq370zcLQxj6qHlj5ub5/tp9a9Rr5zebjR6Kh11EBU8D22/IH9ntQdjb75uNruvi0EfDmvbHnvP8X/0M7Tk+beKFp0hD5vfarVG335n24m6xFvroYljTLq/zJb+/hf13fqPruh5mwthDNzXtSSnqmtqfmd/fz9x5PQxDofPRTXWySipdZiDOd2nUfUh2PgzDtRg/mTRujQq/N+mfiXldD8P1ei2MPTQpaefvWXXk+3vYX/umoAseKhyOR3RZnCKTit+bO/8c12/M+vr933ptmpEo9tCp1tX83ujvLN/DUEL/aNt50zTXorqHpn1vjYrbwt2Z2hndNEWxh6zqjVnHPP8enp1x75xuaq4IX37639JlkuxQ7rDn081jEDViD1nWdLlI+j0dkFbaDyn9raCbptd8fwdZL09BRpKkrce5rL+H58f8ukQ3BS9vIWvgJnyq/NWe7//65nup0pbpptfMPOQG7sJ13SAIgiDwfd/zPM/T6stdkMwU3hq11vkK3SRuE7/fZ1lGCEmSJE3TKIqiWLAMIwhKRnmZqfSqtGZl+a34nC80oLIWQXCyJTJ7+F2MP6B9jc8M6GNDsTPcFLPe4+p0M3El+IyUDDiZUFldVvjMiiSUaDdN0y+9sVvgK/zcgnxFsiX1i6dpWhKK6GYgxBd8bkDDhg6LBDZomqYFTbxbe10aHQo+M6BkQm31sKVqROBpGqnxG/gSPzegzQipNUIj3EDTtLgVz/jcgIoJgtVpicAIw/OSPPYXpIHn/MKAPmYIbZGHh+v7LpNf/aIAOpT4dQtEq4clIhvS1A2CtWkaqQBfMqCfETJb2gI1WQTB4hBXviODim+q7btXX0OaRvAfSRonEnxPEzqsaYtSUvqCTo4/HoTra4Y0jMh/qn89Ch2PEgNkq7cZzfjMsvqX09DxeLYBXbYIjch/3le+H4KKN3g+AS/91/zjfr/PP4pCgxt4em3oKFp9mGesLMsk/4KO/+v6n/H/DQCV6b9EBK/5yAAAAABJRU5ErkJggg==" alt="">Explore<br> source<br> codes</h2>
			<p>See source code of <a href="#template">this page template</a>, <a href="#layout">layout template</a> and
			<a href="#presenter">corresponding presenter</a>. And feel free to modify them!</p>
		</div>

		<div>
			<h2><a href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/adminer/"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAABVCAYAAADaKbMjAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAE3RJREFUeNrsnAl0HPV9x79z7aHVuStpZVu2ZBvbso1twIEGAtgUCASatAmENH0Umr7i53CkbfJylJC06d33KI+kTR+p05QW0pCXlBIgNTZQSh/lSGzsYBtfEnYMklar1bFa7Wp35+rv/59ZaXY0u/Kx9q6Lxu/n3Zm9Zj7z/R3/339GgmmamF/OfBHnEcyDnAc5D3J+mQc5D3Ie5PtrkROJEc8XBEEoPA2TLSfT34d8JLI+stHChlJ1t1zmS+4h+wZZZF5vmCJ7lOwL9vPZwhseTri3BcmOkHWKYvU8n535Ghx1MYgryPpnKdK9r+TRHCJ77vMpVTsYVdWg6yyaCFWjxqKbI8QVRHbU5jNazrVvJ24comFYivD7/ZAk6ZwCZftumuwAzKpCzOdVZLM5etQgioIT5vfIfsMFsmhnP2o7FgIBPxoaGt7XgTEYlMmCSKczZGmnOrtnlT+FWGTbKvao6wbq60PzKcZeQqE6GMTEwUl3caMYWfwZXuIIlGTGxschy3JVnEvgMVLlcRKCUF2KBMnnVyBIYlkWMkrEPo0Owqf4qpZsREGEJNbAeIFOpK7OXULLpUA5ZTtf/uDMQFqJyKyGCP5/gWQvVeNYWOlz3oE0atK1rd81zitFGjUcI43zyrWNGk42xrxrVwIkVb0Qzh/Xrj1FMnj8BOs6TEE4LxUp1YQiWflD8dGwRxbnB8hiRR4m2zBdR1bNtQVSpAHDqNkYKc0F8hmy26ZjFKoYI2m/dEMnpDXp2sdnnfrDR44Wdy1041166GQAW5qauTLO/chGQDabRTafr0WMU4JXY5d1WVwHsYEg/oKU2qmbepWSjeXapqGhxvI2QRRWiJI06uYia5rmPopRSZBW0hF8nij+uU6vC+c4c7JfY/vFOtMn20YTFQWiz28P1Cm+5lUYar4SdRjvjvsU3xO6rv+upmtTLBy6QQrJ8aRrcMamGYyP08P3/X5/kCmWNXrPdRXCQDKb82dFEUrAj+T+/Rj44Q+gjo3C39qG1muvQ8tVV0PPTJ3BQJWdF5HPFthr3yZR3et58j1mEf+B7LOMeDDor0r1wU6aqur25FeZ90kSJEpIb/3BvUjt3oXotddDaWhANjaIqYF+tF53IxZvvRsqxdsKLiyprJwL5CKy9wrlWyDgs3L9OZ/8EkiNOnmG7vkaDzWkRJG85X+u2wxtbAR13cvQQSoU/QH4W1owFY9j4u0DaLjkEizfeg/yudxpeIXOSzCPaelPkz3hGmsXAdpSeMK+IBQKQRRr66oWptLUZAZ19HzHVZdDHR1BoKODg80lEvC1tUKdmEDdokWYGhrA1KFDGHjsUVyw5bOn9XvMMyYmku6a9o9ngyz+3CdgD89aI+GahPhfL72M8dQEjIEBZBMjCDfWkzs38XmmVF8vwk1N0MUstFQKgXAbtMwkxvftw9Ftj2DFXVtP+TcVRUJLSzPi5LkOHplZBbkrCPI0J9A2Np/r8+lVG6ExBRRUYLmziP999TVMTqbgowPa+KnboC1ZhD333sPLJJgKH5tP9vWhcdUqqJOT8JMY9KkMlHAYqYMHCeZ3sOTOz0BzlXxz5zN7WFAGhhCLDTnXd5NdUjiQurq6KiYbaxaRHQSL0bt278HUVBoivXjRReuxaFEnB3xi+3Yc+MP7EOjqghQIUAnkQyASQd2SLv5c8gWQHR6CHGoglSahLF6Ctjt+B0Y6c8px27G8SbaxCLZ7fnZ2o8I851b4fbbvMkF8c89e8pDMLIhs4r5p02Ysuvtz0KnsobPPlZMnt54i12dqVNNpyIEg1ZVZ+MIR5N/pQ7a3j2f8U++PljaxMC/jZdVarMkvXmXj53v2IJNJc0BuiGwYmU4m0XrHnWjYfC10SjKmDVMjgNnBGLTJCXLlvDV2z+fgb48ic/AATFFGuWM/VRPnIl0NY9cdiX4/0n17kcrqJSHmaCzOR0AEc8FX7kfwsg/CSI7DZH1MFmPpNZUyrk5QDQoVJplBn5OCQd59r+Q+i9YXlrLqgBQotuXjMWS+dgsWjb6B9RsvKwmxMFybGByEevudEK6/ESplWFPXbNMtiOy9DCRty4+N2SHEqJiVVWQ14iNTYn5oELF7LkXzehELX/kWOiP1ZSGm05MYHRmBMT6G9t/6bXR+6cvI9vdb4ChhzUDUMfXeuwisWs3VWlFFGva0p7fhnJrJMixB7N/6AbSukSm20YhKzGHwr69FRlW9IU5aENnz9vZ2NPsULL3+Blz6yDaozM2zU7x5YWh56BQCxAWdCKxZA52BLXvsp2Yia+mXsopG4zmMdW6YEgcYxLUEUbMuEtBMH4IaDW/feBAZSj6zII7OQAxTvRih0odd/NXQsxrr/ulfYTaHIVDtqY8nodL2jvt+n8qgSZQ77tMx2SgzHWuco6kGwW8pMXb3pbYS7Q59zkDLEhmh9ZshDO1Co/otJFbfAzGbnIbIXL6trW0aos9nXfiVJPX9kuLme7/2Maivv4YLqPxZ/MU/4oX62ShJyl4gIJwDkII/CJUgDt19GSlRBG+P0k9qeQNhBnHdZjrjVKqIJuqGX0eERjHHOu9CyobY2trqCfGdd95BH41y4jTgiKy7GP4L19pKPDsdf7cifU6Q+lkGaUHsR/zeDyKyhiCqogWRlNi82IZoyhRA87zYNkQ/6odfQ5Rqw9HoZ7CwSSoLcYggRhcsRGNTI4I0rGRzQGfreNyTX0+RXThdyXt0gisGkRKLBfHyaYjsl/S8jmZSYsP6TbQusQ284011DH/UCWZbei98Y49BXfM1ROoC3hDjBHEhQWxsxtKuxRAlcc7+5iksdbOO59ChI871MOEbKYBsaWo6KxcyCb4g8olBjNx3BSKrmTuLPG4xJbZ0MYiWO3MlcoiWmTZMZkI+CaH7BgQ2/0kRxN7eXsSH4hbEpmYs6eyksbpYaUHM6kcWgeQNVV1j0wxPsh9ubmmpeExhEFWCOHrfhwiixLNzAWK4W0Y9UyKHqBYpke+H6TIjg/x4Fuadz+PYuzH00tAvPjyMaMcCNDW1oHPBAohyZSGSqv+dON06a85m3763i7suugpZUjZoefWnkdbwIp50KjRhw915JIaxz12FFoLIu1/syhQGscuGaDqUaMxW4rQiJQH5gV707oxTUPUhdsuX0Fu3FAtb6tBU34AF0ajVPzxDhiami+4p+v/LPT09f5fzmLoQxl2TX3zAbxp/K0D4PFMBa2fNmmk83cQSH0TCVqJuQ2RKjBSUyO4xZb/lVKJpeELMDRLE5xMQZKo3NTrZaQ2TkQXIffwBdF6+iaKreeZz8rR/sqzwya/6UIg1j3eRIq+mnZo6mcmvH5PdYk1+BSriFmyqVB0ZRN8dlxBEwY6JxCxLEJcyiFeXiIlGEVQLoohcfy+OvpDgvUrW4GCmJlVMZaPY+N972azYWStz7DktNvk1VdwhL14uYhCdJRC7YYc1Vs/EvfPD/Th4x0aEewQrO3N31gginen1V9FBiw6IuqcKp5VI7nz0+Tipg1StW2NLBjGnd+Danx+BFAhWlBq7+yuTmeRzNzYDdpXFV8keKNfY3eJs7NbX1/Ph1plCfOuTFyK8kuUPkTPRsgSxm0G8ktYlO7HoFkTDjo0uE0QL4pEdcXYjEAyCyCw3ThCNDlzzWuUh8sKaxu7NzS3WPUcznH599g1LxZ57ZWFqwu9XpifqTwck+0x+ZIAgrqNhn0AxcabEiSxVbIiio070TirOmHjkuQSf5CpAVCc0ghjF5lcOwlR81g1OZ2l6mIW5ZDJVYJGfPflVnNbUQvbO5XJIpVKnFSN5Kyw+QDFxIyI97IYfqwGhs5i4XEYjxUSDKzHvEQ89snOsD4e3J/hB6JoVE/UJUiIoJr6wB2NTOZiT6bM+125BLHHje/n7bE5diWzCKUcQjzGIVGwbdhJmiaV1hYLGdVcSCMEFsZQSReQH+3Dwp3GuxOmYyCAKUXxg517oLNMb+jm5PqmcqCp655fo9yE7PIBf3skSC3mtiumxc+vyAkR24NrspFIouOFQIoP4bBwmQTSZO5Ma1UkNKkHcSBDZlUGmpqEWlord+cXcOUd1IlNieBWDaGdnSiytK/zkzh+ylKirZV2ZQ5RZTDyGg09bSmR1IouJGoMoRnHx83uo1gWfSqiVpSJ3fgmKDbGgRJZYiIlKENtXEsR1BFEvoUQPd84NHMOBp2N8ZMLcmbX61JQGTY7ioh1vQjNqC2JlXJvVc+kxS4krLSUy+mpWn4HIY+JJKJFl59gxvP2T2HRMZGrUJnWoCkF8rjYh2v1IEx5XAwgcov2vfHKREb9/ExqXqKREq52lUmKJcohX2BA1G6BeAqI5DXH/k0NciYbtzuq4DqMuig07diNvWLeM1MBiztUhnw6KVj+SN8nL+TSk9GEYE+M0DJQ5EwaxfZWPYuIV0yWOZ+emKLGIHOK+H8fsvqHBo0B+REPomo+g6y+/i7xWUxA9QBYP7I0Zz2Z/ncMom2xMUpEy/DwQbKCjHqXhH7nzqgCaNvwKgbBKHK/xshV8ixMLg8iA6gUljuiou+ZGLH3wsbM2z3IGEM25XNuWieXa9kSid4FGwzQhl4Y4/DJaL+/BoYdexMYtXZA7VhFE2QWxTGIZPI63fhTj1zcWsnM+oSP0qzeimyDmJiZqLRyaDsGVnGpgK8x/JKbIwtUWJYIjqfEpOnAFLRdGcMWjW5Df9TJMwcc6EicHMXYce38Yg0TKNiiL8LHzsIHmj9yEZQQxNTpaS/fZmA6hGXPFyGEbJGtmEAuhAHLW0Rh08L74swSOEkM+D3nZR2FmnoLZmLHePkdiyQ7aEEVhxp1tiD0P/RtSrE/KvkIwa02NjM+sskHkt6rN2OtklBwN1eAzX+yvshgFm7nWhYZlUuoQJHWEu7BQ300Qh6Hc8EVoJ/ZZQz5++YRjxOIocbKxE/jFEzF+mR4rcXSVlBg30EgQVz70feQyaWt/ULRv1TT2T7dNI0vZezf9TzaKFfkIUWAXW7fQJyUSpOAVI01RQWDoOXoM8CaqEIhSup6CWBdBw5adSG27AdKClfRhfSaxoADxOPY8HuNJpuDO6oiBlptuxoqHHieIGd414edA06v/52pmXLrwyAa+X3Cmm57VK62kwpZDh4/a3RXtJlp9nN7oDwR9PhukODMTQe4uBrH44MegyxEILashBjso9/ggdd9GgChGpkcI5nWQ2pfRD9hKVFh2PoHdjw1yoEyxfOxMEOtv+DCWEsR8cmJ6ukOlUkfX9FrK0qptfypJ0oOMW0/PypnOkFdnY/+Bgwtp/SmyDVxyDpAGJZOWyZewYPwH0JRGyFEqdfQ8lK5bCWKI3iHzDKwdfwbZZ74BsaGVlNpAieVdDlFkpSXvJ1KgIQcJXXM92v/mXwjoqKttVVOlDjujQwTsNykcvbpmTc80QOdcV8l20Vv7DoRbI+E7aK25sHEgqY+vPbH1rwQzF0R4LR8iKt2fguhvpedUlKsp6LGXAF8Tb2+pb+9A7uhu/Owfj0Hx23MsmjX0aw2GtkefO/QK7ZyC2lusLCuK/kRi5Nvr160dcPYmPRq73k1Me2Eyedj5WvrZ6zsVBQ9rYojeZ1As/DAEgsbEraePQRt6hSqjJt75NiUFyupLkUoDmYk+BAMCK6xI1kB3CE+uPjB5KxZ3VmVIV+nF64p0wWWO+Ahx+bKubZKpr+3obKX4eDGk8Eb+CoNoDL5IsbCRvtUPM3UERuJnMNMxhKL1WPaJDahra4B/cGS0/eLFD/e8MMru6VPsk3k6ptj7794uOayw/7L96N7ufF50nB4synfA7AsARJeru7+ILx0dHf7ORdGYpunBV35yF4LN1/E8pk/2Qh96CYK/HUZ2GCapj3ycdjMAicbgQsAHNRB4OZHUv9l95aM77a8LeOxgqV6+13bTY2grOLKr8zPOddNjzOx+7t7m/rzpCoWmW3nOs+PcxhPp8uXLv04x7isbLroYicQwdv7HNiiJp6Elj1sXpk4c5zWkKCu8iWE0yuMTI/l//u6P3vn7r35nP7twm13tFnQAFFwA5rrVzA1oulvlKFEqYYKr5DFdQ0P3+2cBLEhdsR+nXT8QCIjNzc0nurq6gjfffDP2v30IiYGjeOz+C9AWSkObyEBmV4U1+JBVjVf7Die3XfJ7L2+3vyvk+E7R4+SdlPs4DsRwwSzUSbprm+nxGcO1zSjxPt1j3fT6DFOk7BELJI94kVUU5euapgU3bdqEDBXNNDBEIqniinsP44HbmnD7JxvGY8cy39z6wK7v/ecbcXYraj1Z1BV/JMe60yTX+2SXm7rNa7vm2i55vM909BNMRxgzHI+lQoc7vJju2ON1QJIDqkExVKYi9ERbW1tw/fr16O/v55fRsT8dGwwGxzJZfevBA3tftAGEHN/jDtySa5voEZdFj3golHArw+O54ar/SqlqLkV6qdB9UnhLolSGFl1xUiOIf0aPn5ZlOU4mhEIhgQD6/H7/jkQi8Rejo6NMgXUe3+dlmOM5SoA0SzRXTY8kcDJx0B0ivEKAWSIcFEEsdUBeGdtwHRRcKpM8EoZz3SuZCGVAiSViI+ZwMaNM5naDLvVes4Ty4Zg9ML3KirnWTY+Dm2u7WOZ7S5U44ikkmzMpjcptP9kThrlAVmKp1T9mdlZHN/8nwACSOOpOPD/YFAAAAABJRU5ErkJggg==" alt="">Manage<br> database<br> tables</a></h2>
			<p>Manage your database using pre-installed <a href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/adminer/">tool Adminer</a> with an easy to use GUI.<p>
		</div>

		<div>
			<h2><a href="http://doc.nette.org/quickstart"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABVCAYAAAD0bJKxAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAACudJREFUeNrMXG1sFMcZfvfu7ECw7+xDaQL+AApE1B+EJLapSNs4QIhtVWpSVTJNVIkqatX+II1apf8SoTZSq/KHiv5oqRolVaUS5UfgD04qtRAcUGipSrDdjxjHxDa0xOIcDBiMOU9nZj9udndmZ2Y/zjen0d7uzs7u+8z7Pu87H7sGCFLvrqfWGABbwMyBqfW5C5BrvhFYBkFFpiMvP3HlQ94JgwPI43izD+du1dpbn8XArLlRmaLLW+Qiznte3n7lPS4wPU/uyuHN6zg/rXpPwzAvb+kfhSzWGJTMg0fHBfGe3ZQ+hbORonIQcN5wAdOz80kCygnWbOrzeWhsbITabBZyuSz/ptYNjU3HwaidXhIBw6SF4i2YW5iGIlownz+FAUpTKLpfsTQnYwqI9tmgVFVVwUMPb4F8fqWjTsW7RQtiDio43WMsg3S6puwChtXE6lQNrKi6D67dnoC5uzOAiqY8qTS1mHWkTGrXjp1rcB0v2hdtfHAj1pAcLBaLUFxkcvEuzkUr33WdIxipZm1QUMiskHLLmiFtVNHyWAzyfGt/8ufPfc3WmD0swCMj/6RZyCucYy35Mcimb8bCJShZog1MBBysNcRyjmawGW1RIdige4vMAy2RgNIqRfUv4mwCgzUGoTo/XbNUgpTuiipJwGg3qHPIV0Sqij47FHckLqBi/Uiwn1F9JkNYMyqft0EJWh+yhEQ2MAINUeEWFzYoPg5ZMgJmrs2UorQQ3CIhGZSghkSqBsnNIhOKW3wgSmRACVoSitdUEVLkGCOoLxDyAcvlwWR1I+4Jg88xOtzCtaSKETAi+fqVQf8mcZFvbAJGMSUf+YbgFtEDLbmAEJLzXO46KrdYWobEalB+ARN11zG3cFkFFNSLVGkhtLsWAVkm4kVJgcfGMTKyNUS8wlynRb4oIWVBMVxiyTE+Pu7nGCOMlyIcg5ZOQKXLVOo1LGywMJk4ngtVmoBhb2zluvr6mNw1CmEiuMCqulZYXpVzDn08fTo2jYuCXzqdJqYk6F3zHLbQXetz97KqLPxg+3HXsbfO7oW/T7wp65smZ6qMHCnR4DHS+Kl2ztjcsqrXV6xlda+7nKLqq2S2TpUx9Ewk2zX8SKum1tW9nGN9sCyThdsLs9EpBkXgGaIxNGqVZFlFSLMVifAEBJJu3bkGlz8bdgHmKs6bfok4fcKrt6RRyAJGoT4pcCpqypoRoy1j06dg7NNTLnOKRcCwc1sOx0QzXefhdFqQNaORSwMwcnnA2W9r6KPEHMvknSb/8PtKcfSwFXoW9SuaqPB2GsbAEE4hJrW8OucAd/bim1K+6FjXD60NvbD+vseca23zJFo4+NEhrJGnlTmI9a4pbTPlNB2yIl+k0IKstlyaGYbbd2bpcQKQi2cknuTFXX+B/q6DFGQWFJLIfltjH3x/+xHoWNuvSVaS3rU2sSuOdnas3e38H/zoN04ZAkznOvMcEYqYEwVNUCsh7Ib6NijcnKDaMXNz0oqPcrQeG6zdWw/CZdwApBF0vFL43jVjWr6YA4nNiAjjmNHUgHPfkaljLnNqwyZydvywcMj0bx//ES5cOUXLeNO7Q7+AH/Uch3xNM93/8oPfhcNnXpC3HCNHKnIA5+h6sJqSX1tDDwOKCQR7GTnGahYKsOuxT0+XQPHcjmjau8P7S4SONZDvmjmG5It8Ax5CDhxS8iAd60pmNDQ14LvPMHNsw/2PQf29TfzoVUHAS4VhF+foxj+ZOKJGhOTXm2bUXgJh8pjvOgJW4caEYwJtjb1w8j+HlJ5r/f3bqJmSTulqsvUQMrl/weIhmWdSGqhSHbySVUOEZN3pt7/ye245ViBCoif/fUjYbnks7FPtL0F7k98z8RqmcGNSY8w3TJfCg4JKsNXJmBERgpiKLDXk24UCdX5+NzzT8aoPEELIrDnyPI5wAgAJNMaQBG/aw4R2y9Y0USHDJGpORGuQ22ye3XawFA8VhuCd8/thaNLNWwe+Na38jCDsXUO4yTYVjWHNiHDIT99+NBDY57vfoOZBUhfWjPf+5Tanns0/doHyqz89jc1zVjlGEY6Fo4C+UtRhQZ7XIMI5BItbVegMrJ2hiQGXOREuYQtveKBkIu98uJ+CInOuog6n79khYNghCjZeoIhQrBn99cJhqas8P3HMrXFN7i4Cm+asWMhbV3tjrzSY84IS2LtWGWYQDT14BSR/O9eXtOUqNqMpHF/IYh6iASw4XUwd3pRf0ewTkHQnera8FKwxIo2FOE0pQE1ZoVgTkZkkW7bR8k52vVOYV+z0TNersP6Bbc6lG/D/vT1H6DW6QxAIacQxSp5KEOA15NtgpRWskXQGm5GqpRKNeQ5KnmcrBnjgnBnmD/xjP3xnhxkH3Yvd9Qs9R33Xz81fo0TfuLLd/5goeKRWSWPUTImvpl0b3GZ06eqwcmh+ax6b0yeMOeG67NPnsTb9YXAvFZ6XRv97Cva99Ygr/iG9blAZvbMHGzoffoTMYXRHMaOWr1+BbMM8J0AjoXnWinZnKb/oDFuQ+IdkJ3j732lPlJyFzc19kK81y9zCQI3iMrQByPW1pesL1ydx40wG3py8aFG93DjxSt/YE1pdApFZIcGKqqmrw5F4i7Q4EUik/XNYqz4YPSxE9+r1CZqV+4BUEEO/SyAEUXX8Vbl/imIpolXUM0tANSZKV4B1hZUiYGRhoPS+UsjBu3AzbolOmoUcpPeWyUS7GfJzTAUIGLr3617ny/SuwYhgS0ssZAzvQyEA/nLWKKstyy1kIubonnDTJRYNUFDMNBLnKlnJhJveclbRw+mudkhYwDiSOeEWcbItyorNxAQM8W4T8k24RSEIw3AHb2UUMNTtZCuq4nDXNqhIZdVmOQXUvZzTsNK3T3TvVAkCRqlMqDFh3z5BlSSgAvhIiWOSfIYyxDdJfGxDbzlrXBpTRgGDL0UcOQxPgGcEX6TzgOV+Qx/F9aYqf31MtI4dqiQBwzZgrO5a0IlEib1mwq8vjne1E3DX4SfqkhAwDkeR2MuiSypgyLpcqzbB/ARTLIGRaC5ae80/BC+g1lotHmT63nrMkxft3vU5jRGGeEwigdgmjirTGVoRxSP129d+dxTDdU4CrPJy+KitqL0EHsSv8OlOy6bMrzIdoRrzhZYWst2DzxKTqqukFox1BkFSoGo5+fSb8frP+sc/sTkG3j/zAfl6YDfOn4WOY2JuQV2uCfM2iq0p1RiUTJVBrMb5iJlxbba0EulLW79IFrQdAOuDXqpp01cLULv6TqjWLstcEacqEpUQTslU0xCFgNL982+O08nw6xgTB5izj9bBjtFF+r9106a1YH5B8XHcZ6rDLNwddLPN35iBXOMCVFySjgFRD/TLX3+vcMA+dnJwEO7Mz4PhcT6Gwtb5v/P5mrpVGzMPkclMywwMS63dW0CGrba0bMnFSx0fHR803P/NGNRA1mchzW4f2Zrn7DKIBqvc4wCv/XDmhAc+15bUmeYJzcmi4ynBcVkdPOB57Y04HY8wr1UtKlzvnDOs6FcmUCrgWNgt+98LDvuQixwBFz3nZFtRPUIgw4ASJHBKsB+UvfcAjvCybH/gxGD2Fz3gpphjwNn3BbcZibmkJMdk/1MKZhekMSigpXn/FxXKiupzmVIqwP5l/KLDRTJiB0WegSBuAL33TET7XI+k6p1AAigEAGAodM2C3mlBgmMywlbZAjjrqtSTobEvKwsaGgMhQFPd56b/CzAArAe2YDJd4I4AAAAASUVORK5CYII=" alt="">Read<br> Quick-start<br> tutorial</a></h2>
			<p>If you are exploring Nette Framework for the first time, you should read the
			<a href="http://doc.nette.org/quickstart">Quick Start</a>, <a href="http://doc.nette.org">documentation</a>,
			<a href="http://pla.nette.org">tutorials</a> and <a href="http://forum.nette.org">forum</a>.</p>
		</div>
	</div>

	<h2>We hope you enjoy this framework!</h2>

	<section id="template">
		<h2>This page template located at <span><?php echo Latte\Runtime\Filters::escapeHtml(strstr($presenter->template->getFile(), 'app'), ENT_NOQUOTES) ?></span></h2>

		<pre><code class="jush"><?php echo Latte\Runtime\Filters::escapeHtml($template->replacere(file_get_contents($presenter->template->getFile()), '#[\w+/]{60,}#', '…'), ENT_NOQUOTES) ?></code></pre>
	</section>

	<section id="layout">
		<h2>Layout template located at <span><?php echo Latte\Runtime\Filters::escapeHtml(strstr($template->getName(), 'app'), ENT_NOQUOTES) ?></span></h2>

		<pre><code class="jush"><?php echo Latte\Runtime\Filters::escapeHtml(file_get_contents($template->getName()), ENT_NOQUOTES) ?></code></pre>
	</section>

	<section id="presenter">
		<h2>Current presenter located at <span><?php echo Latte\Runtime\Filters::escapeHtml(strstr($presenter->getReflection()->getFileName(), 'app'), ENT_NOQUOTES) ?></span></h2>

		<pre><code class="jush-php"><?php echo Latte\Runtime\Filters::escapeHtml(file_get_contents($presenter->getReflection()->getFileName()), ENT_NOQUOTES) ?></code></pre>
	</section>
</div>
<?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb794aef1512_title')) { function _lb794aef1512_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>	<h1>Congratulations!</h1>
<?php
}}

//
// block scripts
//
if (!function_exists($_b->blocks['scripts'][] = '_lb288c288027_scripts')) { function _lb288c288027_scripts($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;Latte\Macros\BlockMacrosRuntime::callBlockParent($_b, 'scripts', get_defined_vars()) ?>
<script src="http://jush.sourceforge.net/jush.js"></script>
<script>
	jush.create_links = false;
	jush.highlight_tag('code');
	$('code.jush').each(function(){ $(this).html($(this).html().replace(/\x7B[/$\w].*?\}/g, '<span class="jush-latte">$&</span>')) });

	$('a[href^=#]').click(function(){
		$('html,body').animate({ scrollTop: $($(this).attr('href')).show().offset().top - 5 }, 'fast');
		return false;
	});
</script>
<?php
}}

//
// block head
//
if (!function_exists($_b->blocks['head'][] = '_lb3454970eba_head')) { function _lb3454970eba_head($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><style>
	html { overflow-y: scroll; }
	body { font: 14px/1.65 Verdana, "Geneva CE", lucida, sans-serif; background: #3484d2; color: #333; margin: 38px auto; max-width: 940px; min-width: 420px; }

	h1, h2 { font: normal 150%/1.3 Georgia, "New York CE", utopia, serif; color: #1e5eb6; -webkit-text-stroke: 1px rgba(0,0,0,0); }

	img { border: none; }

	a { color: #006aeb; padding: 3px 1px; }

	a:hover, a:active, a:focus { background-color: #006aeb; text-decoration: none; color: white; }

	#banner { border-radius: 12px 12px 0 0; background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAB5CAMAAADPursXAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAGBQTFRFD1CRDkqFDTlmDkF1D06NDT1tDTNZDk2KEFWaDTZgDkiCDTtpDT5wDkZ/DTBVEFacEFOWD1KUDTRcDTFWDkV9DkR7DkN4DkByDTVeDC9TDThjDTxrDkeADkuIDTRbDC9SbsUaggAAAEdJREFUeNqkwYURgAAQA7DH3d3335LSKyxAYpf9vWCpnYbf01qcOdFVXc14w4BznNTjkQfsscAdU3b4wIh9fDVYc4zV8xZgAAYaCMI6vPgLAAAAAElFTkSuQmCC); }
	#banner h1 { color: white; font-size: 50px; line-height: 121px; margin: 0; padding-left: 4%; background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIEAAAA5CAMAAAAm57h6AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAGBQTFRFZ5bIDDJYx8fH9fX11tbWSniovLy9DTpnhrPlMmCQ6+vr/Pz8D0J24+TkWW6Dipusoa24PllztL/L0djfcoedw8vULklkz8/P3d7fIT5a5+fn5+rsCilI8PDwn8z9////dMWpAgAAACB0Uk5T/////////////////////////////////////////wBcXBvtAAAGaklEQVR42uxYa3eqOhAFEQMaIWBEUIr//1/eeWTyAGzPWvf025lam+zMY2eSTKDZ+y9IHuQb6INkfyP4TD/8Zxf6RQYcJ5Ut9IsMJIRCScPHUP57DGYfC0UPCaMI+jUGLphWurHtvbjYeQ5QDdDrYiknv8tAt/3twjLxGsTQMP/mKvB87UWknykHMXRj6M8ZxJt3ZwFXu5tT0PtwjWOgjYdszGD/cGTbCpLvn6XdMaUGH+2SuxQMXx6ahMEnr8IgcrlPIVZQMQEdMn5y+zCCjgztmicMZEyFQxy3xYM/YyocOn0LiyBQHy1Ckq/UPGIQjWtW4KaOo+VKQIGpW4dFmJxdBA2r+DrxmjDAUZSubE2ruNeUTZlMF7EWpVaKUgaAKSTaCAOmBigswhmhLpgPpTdPGPDiwai5X4riUljULntoF8WrVcFB2VM40BktsWxvoB5+YFRZWJUEKibeL8AMXJL95dpESchcCoB5QTGLF9Bp7oVIKwTK8VIEMYiNRSKX4q5uxUrGGecH5tdY04StQAzQm1do4TxHys+cPfQrz7BW3Tpa0U4byMyUgfsKthEDJmD9WFenU+uQQP10/rpBRidlv9bhmmbDoAEGunaa7dA585dPAjCgPeU53u3KBTKoX64N57v1uFlHe/jBAE1ofuZ0Dol5YIAE6q+vr4I+N99ynyFXw4vbePep1o10+eve9ydjrW26rsPqN8/3e3/qUyjHBJIJmRvntpuFARUibb4S6ZvQxtLPLahwWIK4U9BFiBHo28kWwvzumF/xylTEgI/KNSFg89a3TQ7rzdLijpCRdp6ljmKh5fihsuYMUZH2XsFcpuoeJSQHuvk6n/3nCpVslN5Xk6uba3ZK1b0bQAKuitU1pDyqW7hxG8AY0dqZn9fmPgdUWl5nL4d8Vvbpu5NqZHCw5vzkDt66+CBCHXBpXd0VCFVc4bZirsGcZeR7HCbvGMBhf5755/UEArm6nwWAzBs3BCLghA60Hs/nJyGvwd2U+uY9dQ4xgjxjcyaAFDJiPj5Fesxuc/V9OIv9M5GRHNAp92qP2aVAB7XZMRhf++ZuB7kcXEUO5Npw53m9gmv1vEZimtnFx0Lr5NnOrvaXQVGg2ProzXG/EAWV0X3qVejI6uvo+9jz0nbuzBEB3QYzFw0ujw0UzK2Y80Db0Towg1GEamjpu+OAaRQ5Nu5ZmBzUfVCzTEmXxy0UtDoyd/d8eR9rOrrEoDkeR/ocO2RgR+mbnCJJ99HJCdR1O3p4PBp22h9RGOw9FJmrYI7BaDa0E2sYJeMjhTBH6Vt4JKEWdx936xyA50eAQbGubR+6+G0QeiTQvXHm9o7dyTPQ+vhwQjkwDy/Hx0p6W9qMFUwXD7CmOWyhWMuQ+Z2aEy8JMziIYA6UPQR5wK85bOVxgE3bpnqHRzPbVCmBsPugvw/EeUsxA+VjDAh2SaxTl7plMXjTDisMTvp02kBb8xPjXEO4IrUnJx2iuT0Fwfo7d6eVNHwomwgyXGqHH9Q87uo410TFIU3bdFSs8sZI/MHdedYE+9Y5hsI/tXF8uu4mu4EClpiriMEAsYfZV0sw6axtbTeJC7hqp6ZpWvgd/EWMiggDOnlsB6LLe1iZu5cXfEZSTiUeyMMTRp5H130Kpnief4Q+mvOTavRipPLkxWrevmrNKzVmu9VcQ8r/jyl+f3tHDLbCl+c3mI7gPfMfPfr3Rv8qF17sdKS3RRz4fq9xwHag99Yj4+HN1aGkyKAEpa8YETWxVwkaQaK/1aPP3/yP5v+Xfwz+MVgx4KcHvWq6TqIi/dDW+uPQblvvM6gXEO2bpdNT9ZIJg3KpdejrhdR4QMsvByqXpXIeYm8aHKCTfQbowelBE/SU4IvMoITg9OUYlD4H4DWDbpZxN6swUqnW3sCkxll8ZBCTcUy1rjIhDUFgoFqqwECWB5oLMHMpYW5ZpTfeltIn9+cc+BzWlUw6y3AOWaVWOXjjpJeyqjkQ2ADslyT2BoujP9VEzPbibcLKgXEm9hlJWUX7oBatkjjoXQbRPsj+OAeZcwZJD3GqrIQNJssV50Djxltcsrar4LyhiaTjx31QLzosqXjGKIveZVABy8ptDNmJPj/ijUyq6vNp1FFTR+fM55N3e71Eq+C3COhl/tDgno1Oo3ij01j7DbxTkdLiJLXmvapU35Ua/f62Cm0r0n8CDAD34uoT7llrPAAAAABJRU5ErkJggg==) no-repeat 95%; text-shadow: 1px 1px 0 rgba(0, 0, 0, .9); }
	@media (max-width: 600px) {
		#banner h1 { background: none; }
	}

	#content { background: white; border: 1px solid #eff4f7; border-radius: 0 0 12px 12px; padding: 10px 4%; overflow: hidden; }
	#content > h2 { font-size: 130%; color: #666; clear: both; padding: 1.2em 0; margin: 0; }

	h2 span { color: #87A7D5; }
	h2 a { text-decoration: none; background: transparent; }

	.boxes { -webkit-justify-content: space-between; justify-content: space-between; display: -webkit-flex; display: flex; margin-right: -2em; }
	.boxes > div { background: #f0f0f0; border: 1px solid #e6e6e6; border-radius: 5px; -webkit-flex: 1; flex: 1; margin-right: 2em; }
	.boxes h2 { text-align: right; margin: 1em; }
	.boxes img { float: left; }
	.boxes p { clear: both; margin: 1em; }
	.boxes p a { color: #006aeb; background: #f7f7f7; padding: 1px 3px; border-radius: 3px; text-decoration: none; box-shadow: 0 2px 5px rgba(0, 0, 0, .10); }
	.boxes p a:hover, .boxes p a:active, .boxes p a:focus { color: white; background-color: #006aeb; }
	.boxes > div:nth-child(3n - 2) h2 { color: #00a6e5; }
	.boxes > div:nth-child(3n - 2) img { margin: -1em -1em 0 -1em; }
	.boxes > div:nth-child(3n - 1) h2 a { color: #db8e34; background: transparent; }
	.boxes > div:nth-child(3n) h2 a { color: #578404; background: transparent; }
	@media (max-width: 760px) {
		.boxes { -webkit-flex-direction: column; flex-direction: column; }
		.boxes > div { margin-bottom: 1em; }
		.boxes h2 br { display: none; }
	}

	section { display: none; }

	pre { font-size: 12px; line-height: 1.4; padding: 10px; margin: 1.3em 0; overflow: auto; max-height: 500px; background: #F1F5FB; border-radius: 5px; box-shadow: 0 1px 1px rgba(0, 0, 0, .1); }

	.jush-com, .jush-php_doc { color: #929292; }
	.jush-tag, .jush-tag_js { color: #6A8527; font-weight: bold; }
	.jush-att { color: #8CA315 }
	.jush-att_quo { color: #448CCB; font-weight: bold; }
	.jush-php_var { color: #d59401; font-weight: bold; }
	.jush-php_apo { color: green; }
	.jush-php_new { font-weight: bold; }
	.jush-php_fun { color: #254DB3; }
	.jush-js, .jush-css { color: #333333; }
	.jush-css_val { color: #448CCB; }
	.jush-clr { color: #007800; }
	.jush a { color: inherit; background: transparent; }
	.jush-latte { color: #D59401; font-weight: bold }
</style>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars())  ?>

<?php call_user_func(reset($_b->blocks['scripts']), $_b, get_defined_vars())  ?>


<?php call_user_func(reset($_b->blocks['head']), $_b, get_defined_vars()) ; 
}}