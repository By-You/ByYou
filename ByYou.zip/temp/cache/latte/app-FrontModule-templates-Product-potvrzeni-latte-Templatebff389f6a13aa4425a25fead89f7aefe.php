<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\FrontModule/templates/Product/potvrzeni.latte

class Templatebff389f6a13aa4425a25fead89f7aefe extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('faeaa3e55f', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb395df242b4_content')) { function _lb395df242b4_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="mainbar">
    <div class="article">
<?php if ($product) { ?>
            <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin($form = $_form = $_control["potvrzeniForm"], array()) ?>

            <h2><?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>
</h2>
            <img src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>
/images/products/<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($product->id), ENT_COMPAT) ?>.jpg" width="178" height="185" alt="" class="fl"><br>
            <strong>Produkt:</strong> <?php echo Latte\Runtime\Filters::escapeHtml($product->nazev, ENT_NOQUOTES) ?><br>
            <strong>Velikost:</strong> <?php if ($velikost==0) { ?>Neurčuje se<?php } else { echo Latte\Runtime\Filters::escapeHtml($velikost, ENT_NOQUOTES) ;} ?><br>
            <strong>Počet:</strong> <?php echo Latte\Runtime\Filters::escapeHtml($pocet, ENT_NOQUOTES) ?><br>
<?php $cenaCelkem = $pocet*$product->cena ?>
            <strong>Celková cena:</strong> <?php echo Latte\Runtime\Filters::escapeHtml($cenaCelkem, ENT_NOQUOTES) ?> Kč<br>
            <input value=<?php echo '"' . Latte\Runtime\Filters::escapeHtml($product->nazev, ENT_COMPAT) . '"' ;$_input = $_form["nazev"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'value' => NULL,
))->attributes() ?>>
            <input value=<?php echo '"' . Latte\Runtime\Filters::escapeHtml($pocet, ENT_COMPAT) . '"' ;$_input = $_form["kusu"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'value' => NULL,
))->attributes() ?>>
            <input value=<?php echo '"' . Latte\Runtime\Filters::escapeHtml($velikost, ENT_COMPAT) . '"' ;$_input = $_form["velikost"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'value' => NULL,
))->attributes() ?>>
            <input value=<?php echo '"' . Latte\Runtime\Filters::escapeHtml($cenaCelkem, ENT_COMPAT) . '"' ;$_input = $_form["cena"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'value' => NULL,
))->attributes() ?>>

            <h3>Kontaktní údaje:</h3>
            Jméno<br>
            <?php echo $_form["jmeno"]->getControl() ?><br>
            Příjmení<br>
            <?php echo $_form["prijmeni"]->getControl() ?><br>
            E-Mail<br>
            <?php echo $_form["email"]->getControl() ?><br>
            Stát<br>
            <?php echo $_form["stat"]->getControl() ?><br>
            Ulice a č. p.<br>
            <?php echo $_form["ulice"]->getControl() ?><br>
            Město<br>
            <?php echo $_form["mesto"]->getControl() ?><br>
            PSČ<br>
            <?php echo $_form["psc"]->getControl() ?><br>

            <?php echo $_form["send"]->getControl() ?>

            <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd($_form) ?>

<?php } else { ?>
            Nastala chyba!
<?php } ?>
    </div>
</div><?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb0a4c0250e2_title')) { function _lb0a4c0250e2_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><span>Potvrzení objednávky</span><?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}