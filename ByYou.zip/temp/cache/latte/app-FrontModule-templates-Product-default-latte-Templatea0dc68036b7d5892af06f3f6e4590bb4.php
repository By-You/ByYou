<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\FrontModule/templates/Product/default.latte

class Templatea0dc68036b7d5892af06f3f6e4590bb4 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('a25cd41629', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb0e6f1b3abe_content')) { function _lb0e6f1b3abe_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="mainbar">
<?php $iterations = 0; foreach ($products as $product) { ?>
        <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin($form = $_form = $_control["productForm"], array()) ?>

        <div class="article">
          <h2><span><?php echo Latte\Runtime\Filters::escapeHtml($product->nazev, ENT_NOQUOTES) ?>
 (<?php echo Latte\Runtime\Filters::escapeHtml($product->cena, ENT_NOQUOTES) ?> Kč)</span></h2>
          <div class="clr"></div>
          <div class="img"><img src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>
/images/products/<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($product->id), ENT_COMPAT) ?>.jpg" width="178" height="185" alt="" class="fl"></div>
          <div class="post_content">
            <p><strong>Počet kusů:</strong></p>
              <ul><?php echo $_form["kusu"]->getControl() ?></ul>
<?php if ($product->velikost) { ?>
            <p><strong>Velikost:</strong></p>
              <ul><?php echo $_form["velikost"]->getControl() ?></ul>
<?php } else { ?>
              <input value=0 type=hidden<?php $_input = $_form["velikost"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'value' => NULL,
  'type' => NULL,
))->attributes() ?>>
<?php } ?>
              <p><?php echo $_form["send"]->getControl() ?></p>
              <input value=<?php echo '"' . Latte\Runtime\Filters::escapeHtml($product->id, ENT_COMPAT) . '"' ;$_input = $_form["id"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'value' => NULL,
))->attributes() ?>>
          </div>
          <div class="clr"></div>
        </div>
        <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd($_form) ?>

<?php $iterations++; } ?>
</div>
<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars()) ; 
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lba59572a2a4_title')) { function _lba59572a2a4_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div style="display: none;">Produkty</div><?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}