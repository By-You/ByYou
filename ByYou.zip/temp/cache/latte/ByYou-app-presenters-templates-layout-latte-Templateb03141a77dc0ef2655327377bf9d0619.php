<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\presenters/templates/@layout.latte

class Templateb03141a77dc0ef2655327377bf9d0619 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('2f76338fc0', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block head
//
if (!function_exists($_b->blocks['head'][] = '_lbef5db3c73d_head')) { function _lbef5db3c73d_head($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;
}}

//
// block scripts
//
if (!function_exists($_b->blocks['scripts'][] = '_lb197f0372d9_scripts')) { function _lb197f0372d9_scripts($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>	<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
	<script src="//nette.github.io/resources/js/netteForms.min.js"></script>
	<script src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/main.js"></script>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<title><?php if (isset($_b->blocks["title"])) { ob_start(); Latte\Macros\BlockMacrosRuntime::callBlock($_b, 'title', $template->getParameters()); echo $template->striptags(ob_get_clean()) ?>
 | <?php } ?>Nette Sandbox</title>

	<link rel="stylesheet" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/css/style.css">
	<link rel="shortcut icon" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/favicon.ico">
	<meta name="viewport" content="width=device-width">
	<?php if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['head']), $_b, get_defined_vars())  ?>

</head>

<body>
<?php $iterations = 0; foreach ($flashes as $flash) { ?>	<div<?php if ($_l->tmp = array_filter(array('flash', $flash->type))) echo ' class="' . Latte\Runtime\Filters::escapeHtml(implode(" ", array_unique($_l->tmp)), ENT_COMPAT) . '"' ?>
><?php echo Latte\Runtime\Filters::escapeHtml($flash->message, ENT_NOQUOTES) ?></div>
<?php $iterations++; } ?>

<?php Latte\Macros\BlockMacrosRuntime::callBlock($_b, 'content', $template->getParameters()) ?>

<?php call_user_func(reset($_b->blocks['scripts']), $_b, get_defined_vars())  ?>
</body>
</html>


<html>
<head>
<title>ByYou</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/coin-slider.css">
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-georgia.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li class="active"><a href="index.html"><span>Hlavní stránka</span></a></li>
          <li><a href="Products.html"><span>Produkty</span></a></li>
          <li><a href="about.html"><span>O nás</span></a></li>
          <li><a href="contact.html"><span>Kontakt</span></a></li>
        </ul>
      </div>
      <div class="logo">
        <h1><a href="index.html">style <span>your smile</span></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt=""></a> <a href="#"><img src="images/slide2.jpg" width="960" height="360" alt=""></a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt=""></a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="clr"></div>
      <div class="mainbar">
        <div class="article">
          <h2><span>Sekce designu</span> a kontaktu s veřejností</h2>
          <div class="clr"></div>
          <div class="img"><img src="images/img1.jpg" width="178" height="185" alt="" class="fl"></div>
          <div class="post_content">
            <p><strong>Výrobní oddělení:</strong></p>
               <ul>Jakub Ševčík (ředitel)</ul>
               <ul>Tomáš Závodník</ul>
               <ul>Nikola Neubergová</ul>
               <ul>Lukáš Randýsek</ul>
            <p><strong>Personální oddělení:</strong></p>
              <ul>Štěpán Kaňa (tiskový mluvčí)</ul>
              <ul>Adam Tomáš</ul>
              <ul>Marek Hamža (grafik)</ul>
          </div>
          <div class="clr"></div>
        </div>
        <div class="article">
          <h2><span>Sekce obchodní strategie </span>a vnitropodnikových záležitostí</h2>
          <div class="clr"></div>
          <div class="img"><img src="images/img2.jpg" width="178" height="185" alt="" class="fl"></div>
          <div class="post_content">
            <p><strong>Oddělení marketingu:</strong></p>
              <ul>Barbora Piňosová (ředitelka)</ul>
              <ul>Patrik Pixa</ul>
            <p><strong>Personální oddělení:</strong></p>
              <ul>Lucie Urbánková (ředitelka)</ul>
              <ul>Adam Tomáš</ul>
              <ul>Kryštof Krejčí</ul>
            <p><strong>Finanční oddělení:</strong></p>
              <ul>Nikola Patočková (ředitelka)</ul>
          </div>
          <div class="clr"></div>
        </div>
      </div>
      <div class="sidebar">
        <div class="searchform">
          <form id="formsearch" name="formsearch" method="post" action="#">
            <span>
            <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Hledat" type="text">
            </span>
            <input name="button_search" src="images/search.gif" class="button_search" type="image">
          </form>
        </div>
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Sponzoři</span></h2>
          <div class="clr"></div>
          <ul class="ex_menu">
            <li><a href="http://www.sspbrno.cz/">SPŠEIT</a><br>
              Střední průmyslová škola elektrotechnická informační technologie</li>
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; SPŠEIT <a href="http://www.sspbrno.cz">MyWebSite</a>.</p>
      <p class="rf">Vytvořili: <a href="http://www.sspbrno.cz">Libor Řádek, Petr Šopf, Jan Bartošek</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
</body>
</html><?php
}}