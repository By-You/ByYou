<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\AdminModule/templates/Login/default.latte

class Template41e7145573b0513bec1adae2cbde6a8f extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('7dc2b424d9', 'html')
;
// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="cs" xml:lang="cs">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Přihlášení - Administrace - ByYou</title>
<link rel="stylesheet" type="text/css" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admins/css/login.css" media="screen">
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/netteForms.js"></script>
</head>
<body>
<div class="wrap">
	<div id="content">
		<div id="main">
			<div class="full_w">
			    <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin($form = $_form = $_control["loginForm"], array()) ?>

<?php if ($form->hasErrors()) { ?>                  <ul class="errors">
<?php $iterations = 0; foreach ($form->errors as $error) { ?>                          <li><?php echo Latte\Runtime\Filters::escapeHtml($error, ENT_NOQUOTES) ?></li>
<?php $iterations++; } ?>
                  </ul><?php } ?>
<br>

					<label for="login">Uživatel:</label>
					<?php echo $_form["login"]->getControl() ?>

					<label for="pass">Heslo:</label>
					<?php echo $_form["pass"]->getControl() ?>

					<div class="sep"></div>
					<?php echo $_form["send"]->getControl() ?>

				<?php echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd($_form) ?>

			</div>
			<div class="footer">&raquo; <a href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>">ByYou</a> | Administrace</div>
		</div>
	</div>
</div>

</body>
</html>
<?php
}}