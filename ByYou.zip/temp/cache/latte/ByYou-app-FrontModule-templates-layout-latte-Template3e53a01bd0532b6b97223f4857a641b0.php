<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\FrontModule/templates/@layout.latte

class Template3e53a01bd0532b6b97223f4857a641b0 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('6f16607546', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block head
//
if (!function_exists($_b->blocks['head'][] = '_lb64f8fbbb75_head')) { function _lb64f8fbbb75_head($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;
}}

//
// block body
//
if (!function_exists($_b->blocks['body'][] = '_lb6210a7a43e_body')) { function _lb6210a7a43e_body($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><body >
	<div class="main">
      <div class="header">
        <div class="header_resize">
          <div class="menu_nav">
            <ul>
              <li <?php if ($_presenter->isLinkCurrent("Homepage:default")) { ?>
class="active"<?php } ?>><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Homepage:"), ENT_COMPAT) ?>
"><span>Hlavní stránka</span></a></li>
              <li <?php if ($_presenter->isLinkCurrent("Product:default")) { ?>class="active"<?php } ?>
><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Product:"), ENT_COMPAT) ?>
"><span>Produkty</span></a></li>
              <li <?php if ($_presenter->isLinkCurrent("About:default")) { ?>class="active"<?php } ?>
><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("About:"), ENT_COMPAT) ?>
"><span>O nás</span></a></li>
              <li <?php if ($_presenter->isLinkCurrent("Kontakt:default")) { ?>class="active"<?php } ?>
><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Kontakt:"), ENT_COMPAT) ?>
"><span>Kontakt</span></a></li>
            </ul>
          </div>
          <div class="logo">
            <h1><a <?php if ($_presenter->isLinkCurrent("Homepage:default")) { ?>
class="active"<?php } ?>>style <span>your smile</span></a></h1>
          </div>
          <div class="clr"></div>
          <div class="slider">
            <div id="coin-slider"> <a href="#"><img src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>
/images/slide1.jpg" width="960" height="360" alt=""></a> <a href="#"><img src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>
/images/slide2.jpg" width="960" height="360" alt=""></a> <a href="#"><img src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/images/slide3.jpg" width="960" height="360" alt=""></a> </div>
            <div class="clr"></div>
          </div>
          <div class="clr"></div>
        </div>
      </div>
      <div class="content">
        <div class="content_resize">
          <div class="clr"></div>
<?php call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars())  ?>
          <div class="sidebar">
            <div class="clr"></div>
            <div class="gadget">
              <h2 class="star"><span>Sponzoři</span></h2>
              <div class="clr"></div>
              <ul class="ex_menu">
                <li><a href="http://www.sspbrno.cz/">SPŠEIT</a><br>
                  Střední průmyslová škola elektrotechnická informační technologie</li>
              </ul>
            </div>
          </div>
          <div class="clr"></div>
        </div>
      </div>
      <div class="footer">
        <div class="footer_resize">
          <p class="lf">&copy; SPŠEIT <a href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>">ByYou</a>.</p>
          <p class="rf"><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link(":Admin:Homepage:"), ENT_COMPAT) ?>
">Administrace</a></p>
          <div style="clear:both;"></div>
        </div>
      </div>
    </div>

<script type="text/javascript">
    var basePath = <?php echo Latte\Runtime\Filters::escapeJs($basePath) ?>;
</script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/cufon-yui.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/cufon-georgia.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/script.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/coin-slider.min.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/netteForms.js"></script>

</body>
<?php
}}

//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lbc4fe10810d_content')) { function _lbc4fe10810d_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php if (isset($_b->blocks["title"])) { ob_start(); Latte\Macros\BlockMacrosRuntime::callBlock($_b, 'title', $template->getParameters()); echo $template->striptags(ob_get_clean()) ?>
 | <?php } ?>ByYou</title>

	<link rel="stylesheet" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/css/coin-slider.css">
	<?php if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['head']), $_b, get_defined_vars())  ?>

</head>

<?php call_user_func(reset($_b->blocks['body']), $_b, get_defined_vars())  ?>
</html>
<?php
}}