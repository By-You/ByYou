<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\AdminModule/templates/@layout.latte

class Template3d2a50ca018cb9f4f0422ed2017088d8 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('c97c5602e9', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb0e13ecb200_content')) { function _lb0e13ecb200_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="cs" xml:lang="cs">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title><?php if (isset($_b->blocks["title"])) { ob_start(); Latte\Macros\BlockMacrosRuntime::callBlock($_b, 'title', $template->getParameters()); echo $template->striptags(ob_get_clean()) ?>
 | <?php } ?>Administrace - ByYou</title>
<link rel="stylesheet" type="text/css" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admins/css/style.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admins/css/navi.css" media="screen">
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admins/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/js/netteForms.js"></script>
<?php if ($_presenter->isLinkCurrent("Content:*")) { ?>
<script src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admins/ckeditor/ckeditor.js"></script>
<script src="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admins/ckeditor/adapters/jquery.js"></script>
<script type="text/javascript">
var basePath = <?php echo Latte\Runtime\Filters::escapeJs($basePath) ?>;

$( document ).ready( function() {
	$( '#input' ).ckeditor();
} );
</script>
<?php } ?>
<script type="text/javascript">
$(function(){
	$(".box .h_title").not(this).next("ul").hide("normal");
	$(".box .h_title").not(this).next("#home").show("normal");
	$(".box").children(".h_title").click( function() { $(this).next("ul").slideToggle(); });
});
</script>
</head>
<body>
<div class="wrap">
	<div id="header">
		<div id="top">
			<div class="left">
				<p>Administrace <strong>ByYou</strong> [ <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Homepage:out"), ENT_COMPAT) ?>
">odhlásit</a> ]</p>
			</div>
			<div class="right">
				<div class="align-right">
					<p>Serverový čas: <strong><?php echo Latte\Runtime\Filters::escapeHtml($date, ENT_NOQUOTES) ?>
, <?php echo Latte\Runtime\Filters::escapeHtml($time, ENT_NOQUOTES) ?></strong></p>
				</div>
			</div>
		</div>
		<div id="nav">
			<ul>
				<li class="upp"><a href="#">Správa obsahu</a>
					<ul>
						<li>&#8250; <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Content:main"), ENT_COMPAT) ?>
">Hlavní stránka</a></li>
						<li>&#8250; <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Content:about"), ENT_COMPAT) ?>
">O nás</a></li>
					</ul>
				</li>
				<li class="upp"><a href="#">Produkty</a>
					<ul>
						<li>&#8250; <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Products:list"), ENT_COMPAT) ?>
">Seznam</a></li>
						<li>&#8250; <a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Products:add"), ENT_COMPAT) ?>
">Přidat</a></li>
					</ul>
				</li>
				<li class="upp"><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Settings:"), ENT_COMPAT) ?>
">Nastavení</a></li>
			</ul>
		</div>
	</div>

	<div id="content">
		<div id="sidebar">
			<div class="box">
				<div class="h_title">&#8250; Správa obsahu</div>
				<ul>
					<li class="b1"><a class="icon view_page" href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Content:main"), ENT_COMPAT) ?>
">Hlavní stránka</a></li>
					<li class="b2"><a class="icon users" href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Content:about"), ENT_COMPAT) ?>
">O nás</a></li>
				</ul>
			</div>

			<div class="box">
				<div class="h_title">&#8250; Produkty</div>
				<ul>
					<li class="b1"><a class="icon category" href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Products:list"), ENT_COMPAT) ?>
">Seznam</a></li>
					<li class="b2"><a class="icon add_page" href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Products:add"), ENT_COMPAT) ?>
">Přidat</a></li>
				</ul>
			</div>
			<div class="box">
				<div class="h_title"><a href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Settings:"), ENT_COMPAT) ?>
">&#8250; Nastavení</a></div>
			</div>
		</div>
		<div id="main">
<?php if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars())  ?>
		</div>
		<div class="clear"></div>
	</div>

	<div id="footer">
		<div class="left">
			<p>Administrace <a href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>">ByYou</a></p>
		</div>
		<div class="right">
			<p><a href="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>">Zpátky na web</a></p>
		</div>
	</div>
</div>

</body>
</html>

<?php
}}