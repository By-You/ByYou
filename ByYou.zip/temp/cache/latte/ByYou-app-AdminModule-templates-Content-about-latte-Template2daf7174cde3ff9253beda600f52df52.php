<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\AdminModule/templates/Content/about.latte

class Template2daf7174cde3ff9253beda600f52df52 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('092f72d843', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb87d0011ef6_content')) { function _lb87d0011ef6_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="full_w">
<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>
				<?php echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin($form = $_form = $_control["editForm"], array()) ?>

					<div class="element">
						<label for="content">Obsah stránky</label>
						<textarea id="input"<?php $_input = $_form["content"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'id' => NULL,
))->attributes() ?>><?php echo $_input->getControl()->getHtml() ?></textarea>
					</div>
					<div class="entry">
						<button type="submit" class="add"<?php $_input = $_form["send"]; echo $_input->{method_exists($_input, 'getControlPart')?'getControlPart':'getControl'}()->addAttributes(array (
  'type' => NULL,
  'class' => NULL,
))->attributes() ?>>Uložit</button>
					</div>
				<?php echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd($_form) ?>

			</div><?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lbddc5f35b6e_title')) { function _lbddc5f35b6e_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>				<div class="h_title">Správa obsahu: O nás</div>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}