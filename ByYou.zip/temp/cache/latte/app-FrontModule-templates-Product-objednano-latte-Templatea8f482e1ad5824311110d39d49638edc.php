<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\FrontModule/templates/Product/objednano.latte

class Templatea8f482e1ad5824311110d39d49638edc extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('37419d47b8', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb3eee700a0d_content')) { function _lb3eee700a0d_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="mainbar">
    <div class="article">
        <h2><?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>
</h2>
        Objednávka proběhla úspěšně. Brzo se Vám ozveme na Vás E-mail.
    </div>
</div><?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb9f7f2a1360_title')) { function _lb9f7f2a1360_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><span>Zboží úspěšně objednáno</span><?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}