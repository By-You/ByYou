<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\FrontModule/templates/Kontakt/default.latte

class Template6ced727ae158f1e2715bd6a9dc221a04 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('2a66d64e1f', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lb96dd28445a_content')) { function _lb96dd28445a_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="mainbar">
        <div class="article">
          <h2><span>Pošlete nám</span> email</h2>
          <div class="clr"></div>
          <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin($form = $_form = $_control["emailForm"], array()) ?>

<?php if ($form->hasErrors()) { ?>          <ul class="errors">
                  <strong>Chyba při odesílání emailu:</strong>
<?php $iterations = 0; foreach ($form->errors as $error) { ?>                  <li><?php echo Latte\Runtime\Filters::escapeHtml($error, ENT_NOQUOTES) ?></li>
<?php $iterations++; } ?>
          </ul>
<?php } ?>
            <ol>
              <li>
                <label for="name">Jméno</label>
                <?php echo $_form["name"]->getControl() ?>

              </li>
              <li>
                <label for="email">Emailová adresa</label>
                <?php echo $_form["email"]->getControl() ?>

              </li>
              <li>
                <label for="message">Text</label>
                <?php echo $_form["message"]->getControl() ?>

              </li>
              <li>
                <?php echo $_form["send"]->getControl() ?>

                <div class="clr"></div>
              </li>
            </ol>
          <?php echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd($_form) ?>

        </div>
      </div>
<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars()) ; 
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb521491af4d_title')) { function _lb521491af4d_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>      <div style="display: none;">Kontaktujte nás</div><?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}