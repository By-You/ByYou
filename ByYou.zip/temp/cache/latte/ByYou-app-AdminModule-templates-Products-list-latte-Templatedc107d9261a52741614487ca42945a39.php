<?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-14.1VC11\data\localweb\ByYou\app\AdminModule/templates/Products/list.latte

class Templatedc107d9261a52741614487ca42945a39 extends Latte\Template {
function render() {
foreach ($this->params as $__k => $__v) $$__k = $__v; unset($__k, $__v);
// prolog Latte\Macros\CoreMacros
list($_b, $_g, $_l) = $template->initialize('20b335e76f', 'html')
;
// prolog Latte\Macros\BlockMacros
//
// block content
//
if (!function_exists($_b->blocks['content'][] = '_lbeec6ea7adf_content')) { function _lbeec6ea7adf_content($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><div class="full_w">
<?php call_user_func(reset($_b->blocks['title']), $_b, get_defined_vars())  ?>
				<br>
				<form action="<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($basePath), ENT_COMPAT) ?>/admin/products/add">
				&nbsp; <button type="submit" class="add">Přidat produkt</button>
				</form>
				<table>
					<thead>
						<tr>
							<th scope="col">ID</th>
							<th scope="col">Název</th>
							<th scope="col">Cena</th>
							<th scope="col" style="width: 1%; white-space: nowrap;">Velikost</th>
							<th scope="col" style="width: 1%;">Obrázek</th>
							<th scope="col">Akce</th>
						</tr>
					</thead>

					<tbody>
<?php $iterations = 0; foreach ($products as $product) { ?>
						<tr>
							<td class="align-center"><?php echo Latte\Runtime\Filters::escapeHtml($product->id, ENT_NOQUOTES) ?></td>
							<td><?php echo Latte\Runtime\Filters::escapeHtml($product->nazev, ENT_NOQUOTES) ?></td>
							<td><?php echo Latte\Runtime\Filters::escapeHtml($product->cena, ENT_NOQUOTES) ?> Kč</td>
							<td style="width: 1%; white-space: nowrap;"><?php if ($product->velikost) { ?>
Určuje se<?php } else { ?>Neurčuje se<?php } ?></td>
							<td><a target="_blank" href="http://localhost/ByYou/images/products/<?php echo Latte\Runtime\Filters::escapeHtml(Latte\Runtime\Filters::safeUrl($product->id), ENT_COMPAT) ?>.jpg">Zobrazit</a></td>
							<td style="width: 1%; white-space: nowrap;">
							    <a class="table-icon edit" title="Upravit" href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Products:edit", array('id' => $product->id)), ENT_COMPAT) ?>
"></a>
                                <a class="table-icon delete" title="Smazat" href="<?php echo Latte\Runtime\Filters::escapeHtml($_control->link("Products:delete", array('id' => $product->id)), ENT_COMPAT) ?>
"></a>
							</td>
						</tr>
<?php $iterations++; } ?>
					</tbody>
				</table>
			</div><?php
}}

//
// block title
//
if (!function_exists($_b->blocks['title'][] = '_lb4aa77d6617_title')) { function _lb4aa77d6617_title($_b, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>				<div class="h_title">Seznam produktů</div>
<?php
}}

//
// end of blocks
//

// template extending

$_l->extends = empty($_g->extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $_g->extended = TRUE;

if ($_l->extends) { ob_start();}

// prolog Nette\Bridges\ApplicationLatte\UIMacros

// snippets support
if (empty($_l->extends) && !empty($_control->snippetMode)) {
	return Nette\Bridges\ApplicationLatte\UIMacros::renderSnippets($_control, $_b, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return $template->renderChildTemplate($_l->extends, get_defined_vars()); }
call_user_func(reset($_b->blocks['content']), $_b, get_defined_vars()) ; 
}}